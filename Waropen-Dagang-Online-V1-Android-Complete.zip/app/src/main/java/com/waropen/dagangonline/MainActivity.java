package com.waropen.dagangonline;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, content;
    ArrayList<Product> products = new ArrayList<>();
    ArrayList<Product> cart = new ArrayList<>();

    static class Product {
        String name, price, seller;
        Product(String n, String p, String s) { name=n; price=p; seller=s; }
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        seedProducts();
        showHome();
    }

    void seedProducts() {
        products.add(new Product("Dress Cendrawasih", "Rp250.000", "Waropen Store"));
        products.add(new Product("Noken Papua", "Rp150.000", "Papua Craft"));
        products.add(new Product("Sagu Papua", "Rp80.000", "Waropen Food"));
    }

    TextView title(String t, int size) {
        TextView v = new TextView(this);
        v.setText(t); v.setTextSize(size); v.setTextColor(Color.rgb(35,35,35));
        v.setPadding(20,18,20,12);
        return v;
    }

    Button btn(String text) {
        Button b = new Button(this);
        b.setText(text); b.setAllCaps(false);
        return b;
    }

    void base(String pageTitle) {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);
        setContentView(root);

        TextView head = title(pageTitle, 22);
        head.setTextColor(Color.WHITE);
        head.setBackgroundColor(Color.rgb(123,63,181));
        root.addView(head, new LinearLayout.LayoutParams(-1, -2));

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(14, 8, 14, 8);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout nav = new LinearLayout(this);
        nav.setGravity(Gravity.CENTER);
        String[] navs = {"Home","Produk","Keranjang","Jualan","Login"};
        for(String n: navs) {
            Button b = btn(n);
            nav.addView(b, new LinearLayout.LayoutParams(0,-2,1));
            if(n.equals("Home")) b.setOnClickListener(v->showHome());
            if(n.equals("Produk")) b.setOnClickListener(v->showProducts());
            if(n.equals("Keranjang")) b.setOnClickListener(v->showCart());
            if(n.equals("Jualan")) b.setOnClickListener(v->showSeller());
            if(n.equals("Login")) b.setOnClickListener(v->showLogin());
        }
        root.addView(nav);
    }

    void showHome() {
        base("Waropen Dagang Online");
        content.addView(title("Marketplace Waropen", 26));
        TextView intro = title("Temukan produk lokal, jual produk Anda, dan hubungi penjual dengan mudah.", 17);
        content.addView(intro);
        Button p=btn("Lihat Produk"); p.setOnClickListener(v->showProducts()); content.addView(p);
        Button s=btn("Mulai Jualan"); s.setOnClickListener(v->showSeller()); content.addView(s);
        content.addView(title("Fitur V1",20));
        content.addView(title("• Login pengguna\n• Daftar produk\n• Keranjang belanja\n• Form tambah produk\n• Checkout\n• Kontak penjual melalui WhatsApp",16));
    }

    void showProducts() {
        base("Daftar Produk");
        for(Product p: products) {
            LinearLayout card=new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(12,12,12,12);
            TextView n=title(p.name,19); card.addView(n);
            card.addView(title(p.price+"  •  "+p.seller,16));
            Button add=btn("Tambah ke Keranjang");
            add.setOnClickListener(v->{ cart.add(p); Toast.makeText(this,"Ditambahkan ke keranjang",Toast.LENGTH_SHORT).show(); });
            Button wa=btn("Chat Penjual");
            wa.setOnClickListener(v->openWhatsApp(p));
            card.addView(add); card.addView(wa);
            content.addView(card);
        }
    }

    void showCart() {
        base("Keranjang");
        if(cart.size()==0) { content.addView(title("Keranjang masih kosong.",18)); return; }
        for(Product p: cart) content.addView(title(p.name+" - "+p.price,17));
        Button checkout=btn("Checkout");
        checkout.setOnClickListener(v->showCheckout());
        content.addView(checkout);
        Button clear=btn("Kosongkan Keranjang");
        clear.setOnClickListener(v->{cart.clear(); showCart();});
        content.addView(clear);
    }

    void showCheckout() {
        base("Checkout");
        EditText name=new EditText(this); name.setHint("Nama pembeli"); content.addView(name);
        EditText phone=new EditText(this); phone.setHint("Nomor WhatsApp"); content.addView(phone);
        EditText address=new EditText(this); address.setHint("Alamat pengiriman"); content.addView(address);
        Button send=btn("Kirim Pesanan");
        send.setOnClickListener(v->{
            StringBuilder msg=new StringBuilder("Pesanan Waropen Dagang Online%0A");
            for(Product p:cart) msg.append("- ").append(p.name).append(" ").append(p.price).append("%0A");
            msg.append("Pembeli: ").append(name.getText()).append("%0AAlamat: ").append(address.getText());
            try {
                Intent i=new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/?text="+msg));
                startActivity(i);
            } catch(Exception e) { Toast.makeText(this,"WhatsApp tidak tersedia",Toast.LENGTH_LONG).show(); }
        });
        content.addView(send);
    }

    void showSeller() {
        base("Jual Produk");
        EditText n=new EditText(this); n.setHint("Nama produk"); content.addView(n);
        EditText price=new EditText(this); price.setHint("Harga, contoh Rp100.000"); content.addView(price);
        EditText seller=new EditText(this); seller.setHint("Nama toko/penjual"); content.addView(seller);
        Button save=btn("Terbitkan Produk");
        save.setOnClickListener(v->{
            if(n.getText().toString().trim().isEmpty() || price.getText().toString().trim().isEmpty()) {
                Toast.makeText(this,"Nama dan harga wajib diisi",Toast.LENGTH_SHORT).show(); return;
            }
            products.add(new Product(n.getText().toString(), price.getText().toString(), seller.getText().toString()));
            Toast.makeText(this,"Produk berhasil ditambahkan",Toast.LENGTH_LONG).show();
            showProducts();
        });
        content.addView(save);
    }

    void showLogin() {
        base("Login");
        EditText email=new EditText(this); email.setHint("Email / username"); content.addView(email);
        EditText pass=new EditText(this); pass.setHint("Password"); pass.setInputType(0x81); content.addView(pass);
        Button login=btn("Login");
        login.setOnClickListener(v->Toast.makeText(this,"Login demo berhasil. Backend/database dapat ditambahkan pada versi berikutnya.",Toast.LENGTH_LONG).show());
        content.addView(login);
        content.addView(title("Catatan: V1 ini adalah prototype offline. Login dan data produk belum terhubung ke server.",15));
    }

    void openWhatsApp(Product p) {
        String msg=Uri.encode("Halo, saya tertarik dengan "+p.name+" ("+p.price+").");
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/?text="+msg))); }
        catch(Exception e){ Toast.makeText(this,"WhatsApp tidak tersedia",Toast.LENGTH_SHORT).show(); }
    }
}
