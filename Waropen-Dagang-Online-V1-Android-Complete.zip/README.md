# Waropen Dagang Online V1

Android marketplace prototype for Waropen.

## Features
- Home marketplace
- Product list
- Add product / seller form
- Shopping cart
- Checkout form
- WhatsApp contact
- Login demo screen

## Important
This V1 is a functional local prototype. Login, product storage, payments, image uploads, and real multi-user accounts require a backend/database in a later version.

## Build
Open this folder as an Android project in AndroidIDE or Android Studio, sync Gradle, then build the debug APK.
